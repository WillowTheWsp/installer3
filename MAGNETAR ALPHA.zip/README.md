# MAGNETAR
- - -
Eliminate Lags and Throttling, Enhance Sounds, Run Your Game Smoothly and Comfortably with No FPS Drops.

# Notes
- - -
- This will improve overall performance but in exchange for a bit increased power usage and may cause heating.

# Compatibility
- - -
- [![Android P](https://img.shields.io/badge/Android-P-lightgreen.svg)](https://developer.android.com/)
- [![Android Q](https://img.shields.io/badge/Android-Q-brightgreen.svg)](https://developer.android.com/)
- [![Magisk](https://img.shields.io/badge/Magisk-19%2B-00B39B.svg)](https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445)
   
# Instructions
- - -
- Download and install the module
- Reboot after you finished installing

# Changelog
- - -
### v0.1 (1908221811)
- Initial Release

# Credits
- [Zackptg5](https://github.com/Zackptg5) for Unity template
- [topjohnwu](https://github.com/topjohnwu) for Magisk