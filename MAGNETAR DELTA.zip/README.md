# MAGNETAR
Eliminate Lags and Throttling, Enhance Sounds, Run Your Game Smoothly and Comfortably with No Substantial Performance Drops

# Community
- [![Channel](https://img.shields.io/badge/Telegram-Channel-red.svg)](https://MAGNETAR1999)
- [![Group](https://img.shields.io/badge/Telegram-Group-red.svg)](https://t.me/MAGNETARCHAT)

# Notes
- This will improve overall performance but in exchange for a bit increased power usage and may cause heating
- Flash at your own risk, I'm not responsible for lost data or bricked devices
- Some phones arent booting when installing the module, try to get logs and send me on the group

# Compatibility
- [![Android 9](https://img.shields.io/badge/Android-9-lightgreen.svg)](https://developer.android.com/)
- [![Android 10](https://img.shields.io/badge/Android-10-brightgreen.svg)](https://developer.android.com/)
- [![Magisk](https://img.shields.io/badge/Magisk-19%2B-00B39B.svg)](https://forum.xda-developers.com/apps/magisk/official-magisk-v7-universal-systemless-t3473445)
- [![Chipset](https://img.shields.io/badge/Qualcomm-Snapdragon-red.svg)](https://qualcomm.com)

- If you want to add your device, ping me on my [telegram account](https://t.me/Kyliekyler)
   
# Instructions
- Download and install the module
- Reboot after you finished installing

# Changelog
### DELTA (1909191327)
- Support for All Devices Using QComm Snapdragon SOC
- Improved System Speed
- Improved App Launch Speed
- Improved IPV4 Traffic
- Improved Module Logging
- Better Temperature
- Lower Battery Consumption
- Adjusted KCAL Values
- Updated Props
- Cleanup and Optimizations thanks to [Hafiz](https://t.me/HafizZiq)

### CHARLIE (1909101057)
- Performance Improvements
- Proper Android 10 Support
- Updated Props
- Extended Min API to 25
- Added More Devices to Run Service Script
- Added Thermal Bin to Entry-Level SOC
- Adjusted Tweaking Values
- Improved Module Logging
- Sound Mod Will Only Be Installed on AOSP Based Android 9 Rom (Device Specific)

### BRAVO (1908312141)
- Performance Improvements
- Adjusted Some Tweaking Values
- Fixed Some Settings That Didn't Get Applied
- Added Thermals On Flagship SOC 
- Added Module Logging
- Added Better BT Libs
- More... (Forgotten)

### ALPHA (1908281710)
- Initial Release

# Credits
- [Hafiz](https://t.me/HafizZiq) for Fixes and Code Optimization
- [K1ks](https://t.me/K1ks1) for His Help & Tweaks To Make This Module Possible
- [Zackptg5](https://github.com/Zackptg5) for Unity template
- [topjohnwu](https://github.com/topjohnwu) for Magisk