## Changelog

- Added Global Refresh Rate Setter
- Adjusted LMK Tuning Aggressiveness
- Adjusted Cooldown Mode Aggressiveness
- Adjusted Minimum Required Magisk Version to v23
- Fixed Automatic ART Optimization Disabler
- Fixed Game Dashboard Profiles
- Fixed Automatic ART Optimization Trigger
- Fixed Refresh-Rate Setting
- Improved Security
- Improved Config Readability
- Updated Copyright Notice
- Updated Dependencies
